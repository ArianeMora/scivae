
import os
import shutil
import tempfile
import unittest
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import sys
from scivae import SupVAE, VAE, Validate
from sciviso import Scatterplot
